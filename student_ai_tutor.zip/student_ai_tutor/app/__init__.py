from flask import Flask
from config import Config

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(Config)

    from app.routes.main import main_bp
    from app.routes.diagnosis import diagnosis_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(diagnosis_bp, url_prefix="/diagnosis")

    from app.routes.planner import planner_bp
    app.register_blueprint(planner_bp, url_prefix="/planner")

    from app.routes.chat import chat_bp
    app.register_blueprint(chat_bp, url_prefix="/chat")

    from app.routes.test import test_bp
    app.register_blueprint(test_bp, url_prefix="/test")
    
    return app